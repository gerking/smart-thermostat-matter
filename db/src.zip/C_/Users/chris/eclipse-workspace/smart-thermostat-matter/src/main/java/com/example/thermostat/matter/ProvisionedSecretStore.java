package com.example.thermostat.matter;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages the factory-provisioned shared secrets for each device, which commissioning
 * checks against. The expected value comes exclusively from here - never from the
 * caller of {@link CommissioningCredentialVerifier#verify(Credentials)}.
 */
public class ProvisionedSecretStore {

    private final Map<String, byte[]> provisionedSecrets = new ConcurrentHashMap<>();

    public void provision(String deviceId, byte[] expectedSecret) {
        provisionedSecrets.put(deviceId, expectedSecret);
    }

    public byte[] lookupExpectedSecret(String deviceId) {
        return provisionedSecrets.get(deviceId);
    }
}
