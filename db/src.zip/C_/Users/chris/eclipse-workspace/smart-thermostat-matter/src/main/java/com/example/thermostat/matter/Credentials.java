package com.example.thermostat.matter;

/**
 * Carries exactly what the device actually sends over the wire during commissioning:
 * its device ID and its factory-provisioned shared secret, encrypted with the fabric
 * join key. Deliberately NO field for the expected value - that must not travel over
 * the same channel as attacker-controlled input.
 */
public class Credentials {

    private final String deviceId;
    private final byte[] encryptedSharedSecret;

    public Credentials(String deviceId, byte[] encryptedSharedSecret) {
        this.deviceId = deviceId;
        this.encryptedSharedSecret = encryptedSharedSecret;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public byte[] getEncryptedSharedSecret() {
        return encryptedSharedSecret;
    }
}
